document.getElementById('name1').innerText = 'Name: Gian Addy T. Marano';
document.getElementById('age1').innerText = 'Age: 19';
document.getElementById('block1').innerText = 'Year&Block: BSIT-2C';
document.getElementById('name2').innerText = 'Name: Lord Zaro Fiber A. Quintanilla';
document.getElementById('age2').innerText = 'Age: 20';
document.getElementById('block2').innerText = 'Year&Block: BSIT-2C';
document.getElementById('songTitle').innerText = 'Title: Ordinary Song';
document.getElementById('songArtist').innerText = 'Artist: Marc Velasco';
document.getElementById('songWriter').innerText = 'Writer: Marc Velasco';
document.getElementById('lyrics').innerText = `Just an ordinary song
To a special girl like you
From a simple guy
Who's so in love with you
I may not have much to show
No diamonds that glow
No limousines to take you where you go
But if you ever find yourself
Tired of all the games you play
When the world seems so unfair
You can count on me to stay
Just take some time to lend an ear
To this ordinary song
Just an ordinary song
To a special girl like you
From a simple guy
Who's so in love with you
I don't even have the looks
To make you glance my way
The clothes I wear may just seem so absurd
But deep inside of me is you
You give life to what I do
All those years may see you through
Still, I'll be waiting here for you
If you have time, please, lend an ear
To an ordinary song
Just an ordinary song
To a special girl like you
From a simple guy
Who's so in love with you`;
